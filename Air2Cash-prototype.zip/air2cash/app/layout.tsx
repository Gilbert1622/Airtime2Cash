import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Air2Cash — Turn Airtime Into Cash',
  description: 'Air2Cash airtime-to-cash web app prototype'
}

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>
}