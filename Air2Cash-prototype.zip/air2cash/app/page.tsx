'use client'

import { useState } from 'react'

const networks = ['MTN', 'Airtel', 'Glo', '9mobile']

export default function Home() {
  const [amount, setAmount] = useState('1000')
  const [network, setNetwork] = useState('MTN')
  const [message, setMessage] = useState('')

  const cash = Math.floor(Number(amount || 0) * 0.8)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    setMessage(`Demo request created: ₦${Number(amount || 0).toLocaleString()} ${network} airtime → ₦${cash.toLocaleString()} cash.`)
  }

  return (
    <main>
      <nav className="nav">
        <div className="brand"><span className="logo">A</span> Air2Cash</div>
        <div className="navlinks"><a href="#how">How it works</a><a href="#sell">Sell Airtime</a><button className="outline">Login</button></div>
      </nav>

      <section className="hero">
        <div className="heroText">
          <span className="pill">🇳🇬 Built for Nigeria</span>
          <h1>Turn your airtime<br/><span>into cash.</span></h1>
          <p>Sell unwanted airtime through Air2Cash and receive the equivalent value in your bank account. Fast, simple and transparent.</p>
          <div className="actions"><a className="primary" href="#sell">Sell Airtime →</a><a className="secondary" href="#how">How it works</a></div>
          <div className="trust"><span>✓ Simple rates</span><span>✓ Secure withdrawals</span><span>✓ Transaction tracking</span></div>
        </div>

        <div className="card" id="sell">
          <div className="cardHead"><div><h2>Sell Airtime</h2><p>Demo conversion rate: 80%</p></div><span className="status">● Demo</span></div>
          <form onSubmit={submit}>
            <label>Network</label>
            <div className="networkGrid">{networks.map(n => <button type="button" key={n} onClick={()=>setNetwork(n)} className={network===n?'network active':'network'}>{n}</button>)}</div>
            <label>Airtime amount</label>
            <div className="amount"><span>₦</span><input value={amount} onChange={e=>setAmount(e.target.value.replace(/[^0-9]/g,''))} inputMode="numeric" /></div>
            <div className="receive"><span>You receive</span><strong>₦{cash.toLocaleString()}</strong></div>
            <button className="submit">Continue →</button>
            {message && <div className="message">{message}</div>}
          </form>
          <small>Prototype only — no real airtime or money is transferred.</small>
        </div>
      </section>

      <section className="stats">
        <div><b>4</b><span>Networks planned</span></div><div><b>80%</b><span>Demo conversion rate</span></div><div><b>24/7</b><span>Transaction tracking</span></div>
      </section>

      <section id="how" className="how">
        <div className="sectionTitle"><span className="pill">HOW IT WORKS</span><h2>Simple from start to finish.</h2><p>Air2Cash is designed to make the process easy for anyone.</p></div>
        <div className="steps">
          <article><i>01</i><h3>Create an account</h3><p>Register and add your bank details for withdrawals.</p></article>
          <article><i>02</i><h3>Submit airtime</h3><p>Select your network and enter the airtime amount.</p></article>
          <article><i>03</i><h3>Get paid</h3><p>After verification, your cash balance becomes available for withdrawal.</p></article>
        </div>
      </section>

      <section className="dashboard">
        <div><span className="pill">USER DASHBOARD</span><h2>Your money, clearly tracked.</h2><p>Future versions will include a full dashboard with wallet balance, pending transactions, bank withdrawals and transaction history.</p><button className="primary">Preview Dashboard</button></div>
        <div className="dashcard"><div className="dashTop"><span>Available Balance</span><b>₦24,500.00</b></div><div className="bar"></div><div className="tx"><span>MTN Airtime</span><b>+ ₦8,000</b></div><div className="tx"><span>Bank Withdrawal</span><b className="muted">− ₦5,000</b></div><div className="tx"><span>Airtel Airtime</span><b>+ ₦4,000</b></div></div>
      </section>

      <footer><div className="brand"><span className="logo">A</span> Air2Cash</div><span>© 2026 Air2Cash. Prototype.</span></footer>
    </main>
  )
}
