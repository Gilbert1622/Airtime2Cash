# Air2Cash Prototype

A mobile-friendly Next.js prototype for an airtime-to-cash service.

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local address shown by Next.js.

## Important
This is a UI/demo prototype. It does not move real airtime or money.
Before production, add authentication, a database, server-side transaction logic,
airtime verification, bank payout integration, fraud controls, audit logs, and
appropriate Nigerian regulatory/compliance review.
